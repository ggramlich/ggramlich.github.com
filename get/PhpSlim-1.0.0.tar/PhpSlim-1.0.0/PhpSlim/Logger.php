<?php
interface PhpSlim_Logger
{
    public function log($string);
}

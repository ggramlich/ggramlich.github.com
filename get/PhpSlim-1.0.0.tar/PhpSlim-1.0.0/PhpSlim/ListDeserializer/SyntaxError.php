<?php
class PhpSlim_ListDeserializer_SyntaxError extends Exception
{
}

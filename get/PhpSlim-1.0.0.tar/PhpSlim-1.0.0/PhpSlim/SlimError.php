<?php
class PhpSlim_SlimError extends Exception
{
}

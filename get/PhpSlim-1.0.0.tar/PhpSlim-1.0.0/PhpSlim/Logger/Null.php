<?php
class PhpSlim_Logger_Null implements PhpSlim_Logger
{
    public function log($string)
    {
    }
}

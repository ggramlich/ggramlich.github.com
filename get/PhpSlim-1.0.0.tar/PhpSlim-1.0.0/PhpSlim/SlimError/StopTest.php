<?php
class PhpSlim_SlimError_StopTest extends Exception
{
}

